#!/usr/bin/env python3
"""
Public Web Server for Companion Simulator (Zero External Dependencies)
Serves `index.html` at `/` and provides `/api/chat` backed by `girlfriend_sim.py`
so your GEMINI_API_KEY or OPENAI_API_KEY remains safely on the server.
"""
import json
import os
from http.server import HTTPServer, SimpleHTTPRequestHandler
import girlfriend_sim as sim

PORT = int(os.environ.get("PORT", "8080"))
BASE_DIR = os.path.dirname(os.path.abspath(__file__))


class CompanionWebHandler(SimpleHTTPRequestHandler):
    def __init__(self, *args, **kwargs):
        super().__init__(*args, directory=BASE_DIR, **kwargs)

    def end_headers(self):
        self.send_header("Access-Control-Allow-Origin", "*")
        self.send_header("Access-Control-Allow-Methods", "GET, POST, OPTIONS")
        self.send_header("Access-Control-Allow-Headers", "Content-Type")
        super().end_headers()

    def do_OPTIONS(self):
        self.send_response(204)
        self.end_headers()

    def do_POST(self):
        if self.path.rstrip("/") == "/api/chat":
            length = int(self.headers.get("Content-Length", "0"))
            raw = self.rfile.read(length).decode("utf-8") if length > 0 else "{}"
            try:
                body = json.loads(raw)
                user_msg = str(body.get("user_message", "")).strip()
                chat_history = body.get("chat_history", [])
                saved_memories = body.get("saved_memories", {})
                state = body.get("state") or sim.create_new_state(interactive=False)

                reply, delta, new_mood = sim.get_companion_reply(
                    user_msg,
                    chat_history,
                    saved_memories,
                    state=state,
                    return_metadata=True,
                )
                conn = sim.get_connection_status()
                payload = {
                    "reply": reply,
                    "delta": delta,
                    "mood": new_mood,
                    "memories": saved_memories,
                    "connection": conn,
                }
                resp_bytes = json.dumps(payload).encode("utf-8")
                self.send_response(200)
                self.send_header("Content-Type", "application/json; charset=utf-8")
                self.send_header("Content-Length", str(len(resp_bytes)))
                self.end_headers()
                self.wfile.write(resp_bytes)
            except Exception as exc:
                err_bytes = json.dumps({"error": type(exc).__name__}).encode("utf-8")
                self.send_response(500)
                self.send_header("Content-Type", "application/json; charset=utf-8")
                self.end_headers()
                self.wfile.write(err_bytes)
            return
        self.send_response(404)
        self.end_headers()


if __name__ == "__main__":
    print(f"Companion Simulator Public Web Server running on http://0.0.0.0:{PORT}")
    HTTPServer(("0.0.0.0", PORT), CompanionWebHandler).serve_forever()
