# Companion Simulator — Public Web Edition

## 1. Run Locally (Linux / fish shell)
```fish
set -x GEMINI_API_KEY "your-gemini-api-key"
python3 app.py
```
Then open `http://localhost:8080` in your browser.

## 2. Deploy as a Static Site (Appwrite Sites / Vercel / GitHub Pages / Netlify)
Deploy `index.html` directly. Each visitor gets isolated browser `localStorage` persistence and full NLU + 9-emotion + memory support.

## 3. Deploy with Backend Server (Render / Railway / Google Cloud Run)
Deploy this folder using the included `Dockerfile` or start command `python3 app.py`, and set `GEMINI_API_KEY` (or `OPENAI_API_KEY`) in your cloud host's environment variables.
